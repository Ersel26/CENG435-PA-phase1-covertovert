# Explanation
## Receiver
- ICMP receiver sniffes for packets. 
- Check if packet has ICMP layer and if its TTL value equal to 1.
- Display satisfying packets.

## Sender
- ICMP sender creates ICMP packets with TTL value=1.
- Send to packet to receiver.

# Authors
Ibrahim Ersel Yigit 2449072
Beyza Nur Koc 2443430
Group 46
https://github.com/Ersel26/CENG435-PA-phase1-covertovert

